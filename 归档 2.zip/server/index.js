// 1.读取文件夹接口
// 2.读取文件接口
// 3.
const getDir = require('./getDir.js');

// 写入文件信息
getDir();